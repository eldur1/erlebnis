import { rN } from 'fcts.js'

export { triad }