import { rN } from 'fcts.js'

export { complementary }