import { rN } from 'fcts.js'

export { monochromatic }